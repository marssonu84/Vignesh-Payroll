Runtime data directory. Do not upload historical error logs or local database files.
